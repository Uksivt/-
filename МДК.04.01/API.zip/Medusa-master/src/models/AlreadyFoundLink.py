class AlreadyFoundLink:
    def __init__(self, id, link, date, hash):
        self.id = id
        self.link = link
        self.date = date
        self.hash = hash
