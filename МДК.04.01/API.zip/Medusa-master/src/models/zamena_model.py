import datetime


class Zamena:
    def __init__(self,link: str, date: datetime.date):
        self.link = link
        self.date = date