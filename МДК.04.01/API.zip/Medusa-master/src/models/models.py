# models.py

from .cabinet_model import Cabinet
from .course_model import Course
from .group_model import Group
from .parsed_date_model import ParsedDate
from .teacher_model import Teacher
from .paras_model import Paras