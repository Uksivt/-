from .tasks import get_latest_zamena_link, check_new, parse_zamena
